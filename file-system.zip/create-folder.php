<?php
mkdir("New folder/testing"); // This Function Make directory. 
?>

